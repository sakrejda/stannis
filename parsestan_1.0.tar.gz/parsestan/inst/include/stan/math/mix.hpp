#ifndef STAN__MATH__MIX_HPP
#define STAN__MATH__MIX_HPP

#include <stan/math/mix/core.hpp>
#include <stan/math/mix/arr.hpp>
#include <stan/math/mix/mat.hpp>
#include <stan/math/mix/scal.hpp>

#endif
