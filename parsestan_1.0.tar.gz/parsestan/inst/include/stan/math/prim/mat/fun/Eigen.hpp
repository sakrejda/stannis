#ifndef STAN__MATH__PRIM__MAT__FUN__EIGEN_HPP
#define STAN__MATH__PRIM__MAT__FUN__EIGEN_HPP

#include <Eigen/Dense>
#include <Eigen/QR>
#include <Eigen/src/Core/NumTraits.h>

#endif
