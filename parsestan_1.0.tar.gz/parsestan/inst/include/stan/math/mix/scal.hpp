#ifndef STAN__MATH__MIX__SCAL_HPP
#define STAN__MATH__MIX__SCAL_HPP

#endif
