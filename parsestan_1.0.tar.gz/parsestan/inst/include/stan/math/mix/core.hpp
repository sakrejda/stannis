#ifndef STAN__MATH__MIX__CORE_HPP
#define STAN__MATH__MIX__CORE_HPP

#include <stan/math/rev/core.hpp>
#include <stan/math/fwd/core.hpp>

#endif
