#ifndef STAN_LANG_HPP
#define STAN_LANG_HPP

#include <stan/lang/ast.hpp>

#endif
